package IljaM;


import IljaM.AppointmentDB;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//JAX-RS
import javax.ws.rs.*;
import javax.ws.rs.core.*;

import org.joda.time.DateTime;

//AWS SDK
import com.amazonaws.auth.*;
import com.amazonaws.services.applicationdiscovery.model.ResourceNotFoundException;
import com.amazonaws.services.dynamodbv2.*;
import com.amazonaws.services.dynamodbv2.datamodeling.*;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig.SaveBehavior;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.DescribeTableRequest;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.TableDescription;
import com.amazonaws.services.dynamodbv2.model.TableStatus;

@Path("/appointment")
public class AppointmentAPI {
	
	public DynamoDBMapper mapper;
	public AmazonDynamoDB dynamoDB;
	
	public AppointmentAPI() {
		AWSCredentials credentials = new DefaultAWSCredentialsProviderChain().getCredentials();
		AmazonDynamoDB dynamoDB = new AmazonDynamoDBClient(credentials);
		dynamoDB.setEndpoint("http://localhost:8000");
		this.dynamoDB = dynamoDB;
		DynamoDBMapper mapper = new DynamoDBMapper(dynamoDB);
		this.mapper = mapper;
		// If u run first time uncommend, add 1 appointment, then commend again!
		//this.createDB();
	}
	
	public DynamoDBMapper getMapper() {
		return this.mapper;
	}
	
	public AmazonDynamoDB getDynamoDB() {
		return this.dynamoDB;
	}
	
	public static boolean doesTableExist(AmazonDynamoDB dynamo, String tableName) {
	    try {
	        TableDescription table = dynamo.describeTable(new DescribeTableRequest(tableName))
	                .getTable();
	        return TableStatus.ACTIVE.toString().equals(table.getTableStatus());
	    } catch (ResourceNotFoundException rnfe) {
	        return false;
	    }
	}
	
	public void createDB() {
		CreateTableRequest req = this.getMapper().generateCreateTableRequest(AppointmentDB.class);
		req.setProvisionedThroughput(new ProvisionedThroughput(1L, 1L));
		this.dynamoDB.createTable(req);
	}
	
@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/user_name/{user_name}")
	public Iterable<AppointmentDB> getUserAppointments(
			@PathParam("user_name") String user_name)
	{
		DynamoDBMapper mapper = this.getMapper();
		if (user_name != null) {
			Map<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
	        eav.put(":val", new AttributeValue().withS(user_name));
	        DynamoDBScanExpression scanExpression  = new DynamoDBScanExpression()
	    	    .withFilterExpression("user_name = :val")
	            .withExpressionAttributeValues(eav);
	        List<AppointmentDB> appointments = mapper.scan(AppointmentDB.class, scanExpression);
	        System.out.println(appointments.size());
	        return appointments;
		} else {
			Response.status(404).entity("Username not found.").build();
		}
		return null;
		
	}
	
@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/user_name/{user_name}/{from}/{to}")
	public Iterable<AppointmentDB> getUserAppointmentsPeriod(
			@PathParam("user_name") String user_name, 
			@PathParam("from") String from,
			@PathParam("to") String to)
	{
		if (user_name != null && from != null && to != null) {
			
			DynamoDBMapper mapper = this.getMapper();
			
			Map<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
	        eav.put(":val", new AttributeValue().withS(user_name));
	        
	        DynamoDBScanExpression scanExpression  = new DynamoDBScanExpression()
	    	    .withFilterExpression("user_name = :val")
	            .withExpressionAttributeValues(eav);
	        
	        List<AppointmentDB> appointments = mapper.scan(AppointmentDB.class, scanExpression);
	        
	    	long parsed_from = Long.parseLong(from);
			long parsed_to = Long.parseLong(to);
			
			List<AppointmentDB> appointments_needed = new ArrayList<AppointmentDB>();
			
	        for (int i = 0; i < appointments.size(); i++) {
	        	
	        	AppointmentDB appointment = appointments.get(i);
	        	Long date = appointment.getDate_time();
	        	
				if (parsed_from <= date && date <= parsed_to) {
					
					appointments_needed.add(appointment);
				}
			}
			return appointments_needed;
			
		} else {
			Response.status(404).entity("Username, From and To dates required.").build();
		}
		return null;
		
	}
	
@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/user_name/{user_name}/on/{date}")
	public Iterable<AppointmentDB> getUserAppointmentsOnDate(
			@PathParam("user_name") String user_name,
			@PathParam("date") String date)
	{
		if (user_name != null && date != null) {
			
			DynamoDBMapper mapper = this.getMapper();

			Map<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
	        eav.put(":val", new AttributeValue().withS(user_name));
	        
	        DynamoDBScanExpression scanExpression  = new DynamoDBScanExpression()
	    	    .withFilterExpression("user_name = :val")
	            .withExpressionAttributeValues(eav);
	        
	        List<AppointmentDB> appointments = mapper.scan(AppointmentDB.class, scanExpression);
	        
	    	long parsed_date = Long.parseLong(date);
	    	
			List<AppointmentDB> appointments_needed = new ArrayList<AppointmentDB>();
			
	        for (int i = 0; i < appointments.size(); i++) {
	        	
	        	AppointmentDB appointment = appointments.get(i);
	        	Long date1 = appointment.getDate_time();
	        	
				if (new DateTime(parsed_date).getDayOfMonth() == new DateTime(date1).getDayOfMonth()) {
					
					appointments_needed.add(appointment);
				}
			}
			return appointments_needed;
			
		} else {
			Response.status(404).entity("Username and date required.").build();
		}
		return null;
		
	}

@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	public AppointmentDB getUserAppointmentById(
			@PathParam("id") String id)
	{
		if (id != null) {
			
			DynamoDBMapper mapper = this.getMapper();
			AppointmentDB appointment = mapper.load(AppointmentDB.class, id);
			return appointment;
			
		} else {
			Response.status(404).entity("Id is required.").build();
		}
		return null;
	}
	
@POST
	@Produces(MediaType.TEXT_PLAIN)
	public Response addUserAppointment(
			@FormParam("description") String description,
			@FormParam("date_time") String date_time,
			@FormParam("duration") String duration,
			@FormParam("user_name") String user_name)
	{
		try	{
			DynamoDBMapper mapper = this.getMapper();

			long parsed_date_time = Long.parseLong(date_time);
			long parsed_duration = Long.parseLong(duration);

			AppointmentDB appointment = new AppointmentDB();
			appointment.setDate_time(parsed_date_time);
			appointment.setDuration(parsed_duration);
			appointment.setDescription(description);
			appointment.setUser_name(user_name);

			mapper.save(appointment);
			return Response.status(201).entity("Saved.").build();
			
		} catch (Exception e) {
			
			return Response.status(400).entity("Error: " + e).build();
		}
	}
	
@PUT
	@Produces(MediaType.TEXT_PLAIN)
	public Response update(
			@FormParam("id") String id,
			@FormParam("description") String description,
			@FormParam("date_time") String date_time,
			@FormParam("duration") String duration,
			@FormParam("user_name") String user_name) {
		try	{
			
			DynamoDBMapper mapper = this.getMapper();
			DynamoDBMapperConfig dynamoDBMapperConfig = new DynamoDBMapperConfig(SaveBehavior.UPDATE);
			
			long parsed_date_time = Long.parseLong(date_time);
			long parsed_duration = Long.parseLong(duration);

			AppointmentDB appointment = new AppointmentDB();
			appointment.setId(id);
			appointment.setDate_time(parsed_date_time);
			appointment.setDuration(parsed_duration);
			appointment.setDescription(description);
			appointment.setUser_name(user_name);

			mapper.save(appointment, dynamoDBMapperConfig);
			return Response.status(200)
					.entity("Updated.")
					.build();
			
		} catch (Exception e) {
			
			return Response.status(400).entity("Error: " + e).build();
		}
	}

@DELETE
	@Produces(MediaType.TEXT_PLAIN)
	public Response delete(
			@FormParam("id") String id) {
		try	{
			
			DynamoDBMapper mapper = this.getMapper();
			AppointmentDB appointment = new AppointmentDB();
			appointment.setId(id);

			mapper.delete(appointment);
			return Response.status(200)
					.entity("Deleted.")
					.build();
			
		} catch (Exception e) {
			
			return Response.status(400).entity("Error: " + e).build();
		}
	}
}
