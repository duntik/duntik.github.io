// When the user clicks the button, open the modal
$("#modalBtn").on("click", function(){
	$("#addModal").css("display", "block");
});

$("#addModal span.close").on("click", function(){
	$("#addModal").css("display", "none");
});

$("#editModal span.close").on("click", function(){
	$("#editModal").css("display", "none");
});

$("#show_appointmensBtn").on("click", function(){

	$("#list_of_appointments").empty();

	var from= new Date($("#from").val()).getTime();
	var to= new Date($("#to").val()).getTime();
	var url;

	if (!isNaN(from) && !isNaN(to)) {
		url= "http://localhost:8080/IljaM/api/appointment/user_name/" + $("#user_name").val() + "/" + from + "/" + to;
	}
	else if ((!isNaN(from) && isNaN(to)) || (isNaN(from) && !isNaN(to))) {
		var date = !isNaN(from) ? from : to;
		url= "http://localhost:8080/IljaM/api/appointment/user_name/" + $("#user_name").val() + "/on/" + date;
	}
	else {
		url= "http://localhost:8080/IljaM/api/appointment/user_name/" + $("#user_name").val();
	}

	$.ajax({
	    url: url,
	    type: 'GET',
        dataType: 'json',
	    success: function (data) {
	      var ul= $("#list_of_appointments");
	      for (i=0; i<data.length; i++){
	    	  var date = new Date(data[i].date_time);
					enddate = new Date(date);
					enddate.setMinutes(enddate.getMinutes() + data[i].duration);

					var formattedDate = date.toLocaleDateString('en-US', {
					    weekday: 'short',
					    month: 'short',
					    day: 'numeric',
					    year: 'numeric',
					    hour: '2-digit',
					    minute: '2-digit',
					    hour12: false
					  }).replace(/,/g, ''),
					  formattedTime = enddate.toLocaleTimeString('en-US', {
					    hour: '2-digit',
					    minute: '2-digit',
					    hour12: false
					  });

						var li = "<li><span class='daate_time'>" + formattedDate + ' - ' + formattedTime + " </span>" +
	  "<span class='description'>" + data[i].description + " </span>" + "<h69>" +"<span class='date_time'>" + date + " </span>"+"</h69>" + "<input type='hidden' value=" + data[i].id + " /></li>";
	    	  ul.append(li);
	      }
	      $("#list_of_appointments li").on("click", function(){
	    	  $("#editModal").css("display", "block");
	    	  $("#update_description").val($('span.description', this).text());
	    	  var date2 = new Date($('span.date_time', this).text()).toISOString();
	    	  $("#update_date_time").val(date2);
	    	  $("#update_duration").val($('span.duration', this).text());
	    	  $("#editModal input[type='hidden']").val($(this).find("input[type='hidden']").val());
	      });
	    }
	 });
});

$("#new_saveBtn").on("click", function(){

	var description= $("#new_description").val();
	var date_time= new Date($("#new_date_time").val()).getTime()+"";
	var duration= $("#new_duration").val();
	var user= $("#user_name").val();
	var descriptionLength= description.length;


	if (description != "" && date_time != null && duration != "") {
		 $.ajax({
		    url: "http://localhost:8080/IljaM/api/appointment",
		    type: 'POST',
		    data:
		    {
		    	"description": description,
		    	"date_time": date_time,
		    	"duration": duration,
		    	"user_name": user
		    },
		    success: function (returndata) {
					$("#addModal").hide();
		      alert(returndata);
		    }
		 });
	} else if (description == "" || descriptionLength >= 101){
		alert("Description is required. Maximum 100 symbols.");
	} else if ( date_time == null){
		alert("Date and Time is required.");
	} else if (duration.match(/^\d+$/)){
		alert("Only numbers. Duration is required.");
	}
});

$("#update_deleteBtn").on("click", function(){
	var id= $("#editModal input[type='hidden']").val();
	$.ajax({
		url: "http://localhost:8080/IljaM/api/appointment/",
	    type: 'DELETE',
	    data: {"id":id},
	    success: function(data){
				$("#editModal").hide();
	    	alert(data);
	    }
	});
});

$("#update_saveBtn").on("click", function() {
	  var user_name= $("#user_name").val();
	  var description= $("#update_description").val();
	  var date_time= new Date($("#update_date_time").val()).getTime()+"";
	  var duration= $("#update_duration").val();
	  var id= $("#editModal input[type='hidden']").val();

		if (description != "" && date_time != null && duration != "") {
	  $.ajax({
	    url: "http://localhost:8080/IljaM/api/appointment",
	    type: 'PUT',
	    data:
	    {
	    	"id": id,
	    	"description": description,
	    	"date_time": date_time,
	    	"duration": duration,
	    	"user_name": user_name
	    },
	    success: function (returndata) {
				$("#editModal").hide();
	      alert(returndata);
	    }
	 });
 } else if (description == "" || descriptionLength >= 101){
 		alert("Description is required. Maximum 100 symbols.");
 	} else if ( date_time == null){
 		alert("Date and Time is required.");
 	} else if (duration.match(/^\d+$/)){
 		alert("Only numbers. Duration is required.");
 	}
});
